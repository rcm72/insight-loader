prompt --application/shared_components/logic/application_items/app_neoj_url
begin
--   Manifest
--     APPLICATION ITEM: APP_NEOJ_URL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.13'
,p_default_workspace_id=>7001029092517363
,p_default_application_id=>209
,p_default_id_offset=>0
,p_default_owner=>'Y055490'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(68270925875574308)
,p_name=>'APP_NEOJ_URL'
,p_protection_level=>'I'
,p_version_scn=>48751644982586
);
wwv_flow_imp.component_end;
end;
/
