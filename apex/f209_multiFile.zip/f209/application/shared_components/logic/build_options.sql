prompt --application/shared_components/logic/build_options
begin
--   Manifest
--     BUILD OPTIONS: 209
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.13'
,p_default_workspace_id=>7001029092517363
,p_default_application_id=>209
,p_default_id_offset=>0
,p_default_owner=>'Y055490'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(57272775508498395)
,p_build_option_name=>'Commented Out'
,p_build_option_status=>'EXCLUDE'
,p_version_scn=>48748319436030
);
wwv_flow_imp.component_end;
end;
/
