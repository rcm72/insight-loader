prompt --application/shared_components/user_interface/lovs/me_legacy_application_app_code
begin
--   Manifest
--     ME_LEGACY_APPLICATION.APP_CODE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.13'
,p_default_workspace_id=>7001029092517363
,p_default_application_id=>209
,p_default_id_offset=>0
,p_default_owner=>'Y055490'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(57407767044574881)
,p_lov_name=>'ME_LEGACY_APPLICATION.APP_CODE'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'ME_LEGACY_APPLICATION'
,p_return_column_name=>'LEGACY_APP_ID'
,p_display_column_name=>'APP_CODE'
,p_default_sort_column_name=>'APP_CODE'
,p_default_sort_direction=>'ASC'
,p_version_scn=>48748368794467
);
wwv_flow_imp.component_end;
end;
/
