prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 209
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.13'
,p_default_workspace_id=>7001029092517363
,p_default_application_id=>209
,p_default_id_offset=>0
,p_default_owner=>'Y055490'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(74850749048412286)
);
wwv_flow_imp.component_end;
end;
/
