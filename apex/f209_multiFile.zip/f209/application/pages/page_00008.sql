prompt --application/pages/page_00008
begin
--   Manifest
--     PAGE: 00008
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.13'
,p_default_workspace_id=>7001029092517363
,p_default_application_id=>209
,p_default_id_offset=>0
,p_default_owner=>'Y055490'
);
wwv_flow_imp_page.create_page(
 p_id=>8
,p_name=>'APEXAppllications'
,p_alias=>'APPLLICATIONS'
,p_step_title=>'Appllications'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(59604691702866614)
,p_plug_name=>'Pages'
,p_region_name=>'PAGES_RGN'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    application_id,',
'    workspace,',
'    application_name,',
'    page_id,',
'    page_name,',
'    page_mode,',
'    page_alias,',
'    page_group,',
'    last_updated_on,',
'   ''APEX_2_NEO4J'' AS load_action',
'FROM apex_application_pages',
'where application_id = :P08_APPLICATION_ID',
' and :P08_APPLICATION_ID IS NOT NULL',
'ORDER BY application_id, page_id;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P08_APPLICATION_ID,P8_WORKSPACE,P8_PROJECT_NAME,P8_PAGE_ID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(59604708217866615)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'CMRLECR'
,p_internal_uid=>59604708217866615
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(59604870292866616)
,p_db_column_name=>'APPLICATION_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Application Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(59606128104866629)
,p_db_column_name=>'WORKSPACE'
,p_display_order=>20
,p_column_identifier=>'I'
,p_column_label=>'Workspace'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(59606284353866630)
,p_db_column_name=>'APPLICATION_NAME'
,p_display_order=>30
,p_column_identifier=>'J'
,p_column_label=>'Application Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(59604959689866617)
,p_db_column_name=>'PAGE_ID'
,p_display_order=>40
,p_column_identifier=>'B'
,p_column_label=>'Page Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(59605018114866618)
,p_db_column_name=>'PAGE_NAME'
,p_display_order=>50
,p_column_identifier=>'C'
,p_column_label=>'Page Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(59605134702866619)
,p_db_column_name=>'PAGE_MODE'
,p_display_order=>60
,p_column_identifier=>'D'
,p_column_label=>'Page Mode'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(59605288540866620)
,p_db_column_name=>'PAGE_ALIAS'
,p_display_order=>70
,p_column_identifier=>'E'
,p_column_label=>'Page Alias'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(59605326433866621)
,p_db_column_name=>'PAGE_GROUP'
,p_display_order=>80
,p_column_identifier=>'F'
,p_column_label=>'Page Group'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(59605446420866622)
,p_db_column_name=>'LAST_UPDATED_ON'
,p_display_order=>90
,p_column_identifier=>'G'
,p_column_label=>'Last Updated On'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(59605745454866625)
,p_db_column_name=>'LOAD_ACTION'
,p_display_order=>110
,p_column_identifier=>'H'
,p_column_label=>'Load Action'
,p_column_link=>'f?p=&APP_ID.:8:&SESSION.:RUN_PREPARE_APEX_PAGE:&DEBUG.::P08_APPLICATION_ID,P8_WORKSPACE,P8_PROJECT_NAME,P8_PAGE_ID:#APPLICATION_ID#,#WORKSPACE#,#WORKSPACE#,#PAGE_ID#'
,p_column_linktext=>'#LOAD_ACTION#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(66759157562538375)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'667592'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'APPLICATION_ID:PAGE_ID:PAGE_NAME:PAGE_MODE:PAGE_ALIAS:PAGE_GROUP:LAST_UPDATED_ON'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(66569511892303691)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(57273370873498396)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(66570292601303700)
,p_plug_name=>'Appllications'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    WORKSPACE,',
'    WORKSPACE_DISPLAY_NAME,',
'    APPLICATION_ID,',
'    APPLICATION_NAME,',
'    ALIAS,',
'    OWNER,',
'    CREATED_BY,',
'    CREATED_ON,',
'    LAST_UPDATED_BY,',
'    LAST_UPDATED_ON,',
'    GLOBAL_NOTIFICATION,',
'    SESSION_STATE_PROTECTION,',
'    PAGES,',
'    TABS,',
'    PARENT_TABS,',
'    LISTS,',
'    LISTS_OF_VALUES,',
'   ''APEX_2_NEO4J'' AS load_action',
'FROM APEX_APPLICATIONS',
'order by application_id'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P08_APPLICATION_ID,P8_WORKSPACE,P8_PROJECT_NAME'
,p_prn_page_header=>'Appllications'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(66570383517303700)
,p_name=>'Appllications'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'CMRLECR'
,p_internal_uid=>66570383517303700
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(66571011302303711)
,p_db_column_name=>'WORKSPACE'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Workspace'
,p_column_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.::P8_WORKSPACE,P8_PROJECT_NAME,P08_APPLICATION_ID:#WORKSPACE#,#WORKSPACE#,#APPLICATION_ID#'
,p_column_linktext=>'#WORKSPACE#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(66571411592303713)
,p_db_column_name=>'WORKSPACE_DISPLAY_NAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Workspace Display Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(66571897556303713)
,p_db_column_name=>'APPLICATION_ID'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Application Id'
,p_column_link=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.::P08_APPLICATION_ID:#APPLICATION_ID#'
,p_column_linktext=>'#APPLICATION_ID#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(66572255433303714)
,p_db_column_name=>'APPLICATION_NAME'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Application Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(66572602202303714)
,p_db_column_name=>'ALIAS'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Alias'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(66573056181303714)
,p_db_column_name=>'OWNER'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Owner'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(66593048172303730)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>56
,p_column_identifier=>'BD'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(66593488890303730)
,p_db_column_name=>'CREATED_ON'
,p_display_order=>57
,p_column_identifier=>'BE'
,p_column_label=>'Created On'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(66593816547303730)
,p_db_column_name=>'LAST_UPDATED_BY'
,p_display_order=>58
,p_column_identifier=>'BF'
,p_column_label=>'Last Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(66594258927303731)
,p_db_column_name=>'LAST_UPDATED_ON'
,p_display_order=>59
,p_column_identifier=>'BG'
,p_column_label=>'Last Updated On'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(66594638156303731)
,p_db_column_name=>'GLOBAL_NOTIFICATION'
,p_display_order=>60
,p_column_identifier=>'BH'
,p_column_label=>'Global Notification'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(66595039569303731)
,p_db_column_name=>'SESSION_STATE_PROTECTION'
,p_display_order=>61
,p_column_identifier=>'BI'
,p_column_label=>'Session State Protection'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(66606692239303741)
,p_db_column_name=>'PAGES'
,p_display_order=>90
,p_column_identifier=>'CL'
,p_column_label=>'Pages'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(66607000490303741)
,p_db_column_name=>'TABS'
,p_display_order=>91
,p_column_identifier=>'CM'
,p_column_label=>'Tabs'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(66607443809303741)
,p_db_column_name=>'PARENT_TABS'
,p_display_order=>92
,p_column_identifier=>'CN'
,p_column_label=>'Parent Tabs'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(66611856834303745)
,p_db_column_name=>'LISTS'
,p_display_order=>103
,p_column_identifier=>'CY'
,p_column_label=>'Lists'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(66612242204303745)
,p_db_column_name=>'LISTS_OF_VALUES'
,p_display_order=>104
,p_column_identifier=>'CZ'
,p_column_label=>'Lists Of Values'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(68274510963653023)
,p_db_column_name=>'LOAD_ACTION'
,p_display_order=>114
,p_column_identifier=>'DA'
,p_column_label=>'Load Action'
,p_column_link=>'f?p=&APP_ID.:8:&SESSION.:RUN_PREPARE_APEX_ALL:&DEBUG.::P08_APPLICATION_ID,P8_WORKSPACE,P8_PROJECT_NAME:#APPLICATION_ID#,#WORKSPACE#,#WORKSPACE#'
,p_column_linktext=>'#LOAD_ACTION#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(66645106415305793)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'666452'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'WORKSPACE:WORKSPACE_DISPLAY_NAME:APPLICATION_ID:APPLICATION_NAME:ALIAS:OWNER:CREATED_BY:CREATED_ON:LAST_UPDATED_BY:LAST_UPDATED_ON:GLOBAL_NOTIFICATION:SESSION_STATE_PROTECTION:PAGES:TABS:PARENT_TABS:LISTS:LISTS_OF_VALUES'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(59605545475866623)
,p_name=>'P08_APPLICATION_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(66570292601303700)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(59605835960866626)
,p_name=>'P8_WORKSPACE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(66570292601303700)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(59605972636866627)
,p_name=>'P8_PROJECT_NAME'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(66570292601303700)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(68273902825653017)
,p_name=>'P8_URL'
,p_item_sequence=>10
,p_prompt=>'Url'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(68274334094653021)
,p_name=>'P8_DEBUG'
,p_item_sequence=>20
,p_item_default=>'https://testgenpro.generali.si/apex/ws_cmrlecr/apex-structure/export/'
,p_prompt=>'Debug'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(68274413972653022)
,p_name=>'P8_PAGE_ID'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(66570292601303700)
,p_prompt=>'Page Id'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(59606312098866631)
,p_name=>'AfterApplicationRefresh'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(66570292601303700)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(59606450354866632)
,p_event_id=>wwv_flow_imp.id(59606312098866631)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P08_APPLICATION_ID,P8_WORKSPACE,P8_PROJECT_NAME,P8_PAGE_ID'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(59607128902866639)
,p_event_id=>wwv_flow_imp.id(59606312098866631)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P08_APPLICATION_ID := NULL;',
':P8_WORKSPACE := NULL;',
':P8_PROJECT_NAME := NULL;',
':P8_PAGE_ID := NULL;'))
,p_attribute_02=>'P08_APPLICATION_ID,P8_WORKSPACE,P8_PROJECT_NAME,P8_PAGE_ID'
,p_attribute_03=>'P08_APPLICATION_ID,P8_WORKSPACE,P8_PROJECT_NAME,P8_PAGE_ID'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(59606786386866635)
,p_event_id=>wwv_flow_imp.id(59606312098866631)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.item("P08_APPLICATION_ID").setValue("", null, true);',
'apex.item("P8_WORKSPACE").setValue("", null, true);',
'apex.item("P8_PROJECT_NAME").setValue("", null, true);',
'apex.item("P8_PAGE_ID").setValue("", null, true);',
'apex.region("PAGES_RGN").refresh();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(68273569956653013)
,p_name=>'New'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P8_URL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(68273658174653014)
,p_event_id=>wwv_flow_imp.id(68273569956653013)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    :APP_NEOJ_URL := :P8_URL;',
'END;'))
,p_attribute_02=>'P8_URL'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(68273773803653015)
,p_event_id=>wwv_flow_imp.id(68273569956653013)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.message.showPageSuccess("APP_NEOJ_URL = " + $v("P8_URL"));'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(68274053473653018)
,p_name=>'New'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P8_URL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(68274181873653019)
,p_event_id=>wwv_flow_imp.id(68274053473653018)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    :APP_NEOJ_URL := :P8_URL;',
'END;'))
,p_attribute_02=>'P8_URL'
,p_attribute_03=>'P8_DEBUG'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(68274208270653020)
,p_event_id=>wwv_flow_imp.id(68274053473653018)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.message.showPageSuccess("APP_NEOJ_URL = " + $v("P8_URL"));'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(59606049257866628)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RUN_PREPARE_APEX_PAGE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_pn_jobid_regions NUMBER;',
'    l_pn_jobid_buttons NUMBER;',
'    l_PVOUTPUTSOURCE     VARCHAR2(20) := ''CYPHER'';',
'    l_PVOUTPUTTYPE       VARCHAR2(20) := ''FILE'';',
'    l_PVAPEXURL          VARCHAR2(4000) :=:P8_URL;',
'    l_PVOUTCYPHER        CLOB;',
'    l_PVOUTFILE          CLOB;    ',
'    ln_id                number;',
'    ln_master_job_id    number;',
'    l_PN_ID             number;',
'BEGIN',
'    neo4jutils.prepare_apex_all(',
'        pn_app_id        => TO_NUMBER(:P08_APPLICATION_ID),',
'        pv_workspace     => :P8_WORKSPACE,',
'        pn_page_id       => :P8_PAGE_ID,',
'        pv_project_name  => :P8_PROJECT_NAME,',
'        pn_jobid_regions => l_pn_jobid_regions,',
'        pn_jobid_buttons => l_pn_jobid_buttons',
'    );',
'',
'    ln_id:=neoj_order_seq.nextval;',
'',
'    NEO4JUTILS.EXPORT_APEX_ALL_CYPHER(',
'        pn_master_job_id   => ln_master_job_id,',
'        PN_JOBID_REGIONS   => l_PN_JOBID_REGIONS,',
'        PN_JOBID_BUTTONS   => l_PN_JOBID_BUTTONS,',
'        PVOUTPUTSOURCE     => l_PVOUTPUTSOURCE,',
'        PVOUTPUTTYPE       => l_PVOUTPUTTYPE,',
'        PVAPEXURL          => l_PVAPEXURL          ,      ',
'        PVOUTCYPHER        => l_PVOUTCYPHER,',
'        PVOUTFILE          => l_PVOUTFILE,',
'        pn_id              => ln_id',
'    );    ',
'',
'',
'    NEO4JUTILS.LOADAPEXPAGEPROCPKGPRCCALLS (PN_JOBID => l_pn_jobid_buttons);',
'    for s in ( select distinct owner, object_name package_name, project_name from NEOJ_APEX_PACKAGE_PROCEDURE where jobid in (l_pn_jobid_regions, l_pn_jobid_buttons) )',
'    loop',
'        NEO4JUTILS.PREPARE_ORA_ALL (',
'            PN_JOBID          => l_pn_jobid_buttons,',
'            PV_OWNER          => s.OWNER,',
'            PV_PACKAGE_NAME   => s.PACKAGE_NAME,',
'            PV_PROJECT_NAME   => s.PROJECT_NAME,',
'            pv_PTYPE    => ''pkg'');            ',
'    end loop;       ',
'',
'    NEO4JUTILS.EXPORT_ORA_ALL (PN_JOBID          => l_pn_jobid_buttons,',
'                               PVOUTPUTSOURCE    => l_PVOUTPUTSOURCE,',
'                               PVOUTPUTTYPE      => l_PVOUTPUTTYPE,',
'                               PVAPEXURL         => l_PVAPEXURL,',
'                               PV_PROJECT_NAME   => :P8_PROJECT_NAME,',
'                               PVOUTCYPHER       => l_PVOUTCYPHER,',
'                               PVOUTFILE         => l_PVOUTFILE,',
'                               PN_ID             => l_PN_ID',
'                               );             ',
'',
'',
'    apex_application.g_print_success_message :=',
'        ''Prepare APEX finished. REGIONS job id: '' || l_pn_jobid_regions ||',
'        '', BUTTONS job id: '' || l_pn_jobid_buttons||'' URL'';',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>':REQUEST = ''RUN_PREPARE_APEX_ALL'''
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>59606049257866628
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(68274677658653024)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RUN_PREPARE_APEX_ALL'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_pn_jobid_regions NUMBER;',
'    l_pn_jobid_buttons NUMBER;',
'    l_PVOUTPUTSOURCE     VARCHAR2(20) := ''CYPHER'';',
'    l_PVOUTPUTTYPE       VARCHAR2(20) := ''FILE'';',
'    l_PVAPEXURL          VARCHAR2(4000) :=:P8_URL;',
'    l_PVOUTCYPHER        CLOB;',
'    l_PVOUTFILE          CLOB;    ',
'    ln_id                number;',
'    ln_master_job_id    number;',
'    l_PN_ID             number;',
'BEGIN',
'    neo4jutils.prepare_apex_all(',
'        pn_app_id        => TO_NUMBER(:P08_APPLICATION_ID),',
'        pv_workspace     => :P8_WORKSPACE,       ',
'        pv_project_name  => :P8_PROJECT_NAME,',
'        pn_jobid_regions => l_pn_jobid_regions,',
'        pn_jobid_buttons => l_pn_jobid_buttons',
'    );',
'',
'    ln_id:=neoj_order_seq.nextval;',
'',
'    NEO4JUTILS.EXPORT_APEX_ALL_CYPHER(',
'        pn_master_job_id   => ln_master_job_id,',
'        PN_JOBID_REGIONS   => l_PN_JOBID_REGIONS,',
'        PN_JOBID_BUTTONS   => l_PN_JOBID_BUTTONS,',
'        PVOUTPUTSOURCE     => l_PVOUTPUTSOURCE,',
'        PVOUTPUTTYPE       => l_PVOUTPUTTYPE,',
'        PVAPEXURL          => l_PVAPEXURL          ,      ',
'        PVOUTCYPHER        => l_PVOUTCYPHER,',
'        PVOUTFILE          => l_PVOUTFILE,',
'        pn_id              => ln_id',
'    );    ',
'',
'',
'    NEO4JUTILS.LOADAPEXPAGEPROCPKGPRCCALLS (PN_JOBID => l_pn_jobid_buttons);',
'    for s in ( select distinct owner, object_name package_name, project_name from NEOJ_APEX_PACKAGE_PROCEDURE where jobid in (l_pn_jobid_regions, l_pn_jobid_buttons) )',
'    loop',
'        NEO4JUTILS.PREPARE_ORA_ALL (',
'            PN_JOBID          => l_pn_jobid_buttons,',
'            PV_OWNER          => s.OWNER,',
'            PV_PACKAGE_NAME   => s.PACKAGE_NAME,',
'            PV_PROJECT_NAME   => s.PROJECT_NAME,',
'            pv_PTYPE    => ''pkg'');            ',
'    end loop;       ',
'',
'    NEO4JUTILS.EXPORT_ORA_ALL (PN_JOBID          => l_pn_jobid_buttons,',
'                               PVOUTPUTSOURCE    => l_PVOUTPUTSOURCE,',
'                               PVOUTPUTTYPE      => l_PVOUTPUTTYPE,',
'                               PVAPEXURL         => l_PVAPEXURL,',
'                               PV_PROJECT_NAME   => :P8_PROJECT_NAME,',
'                               PVOUTCYPHER       => l_PVOUTCYPHER,',
'                               PVOUTFILE         => l_PVOUTFILE,',
'                               PN_ID             => l_PN_ID',
'                               );             ',
'',
'',
'    apex_application.g_print_success_message :=',
'        ''Prepare APEX finished. REGIONS job id: '' || l_pn_jobid_regions ||',
'        '', BUTTONS job id: '' || l_pn_jobid_buttons||'' URL'';',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>':REQUEST = ''RUN_PREPARE_APEX_ALL'''
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>68274677658653024
);
wwv_flow_imp.component_end;
end;
/
